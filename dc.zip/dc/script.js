let values=0;
    function addcart() {
        values++;
        let item = document.getElementById("item");
        document.getElementById("items").innerHTML = `<b>`+values+`</b>`+" items cart";

    }
    function reducecart() {
        let item = document.getElementById("item");
        document.getElementById("items").innerHTML = `<b>`+values+`</b>`+" items cart";
        if (values > 0) {
            values--;
        }
        else { alert("cart is empty!") }
    }